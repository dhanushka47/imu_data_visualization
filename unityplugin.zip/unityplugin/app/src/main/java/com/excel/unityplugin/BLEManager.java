package com.excel.unityplugin;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;
import androidx.annotation.RequiresPermission;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.*;
import java.util.ArrayList;
import java.util.List;
public class BLEManager {
    public static final int PERMISSION_REQUEST_CODE = 1001;
    private final Activity activity;
    private final BluetoothAdapter bluetoothAdapter;
    private BluetoothLeScanner bluetoothLeScanner;
    private BluetoothGatt bluetoothGatt;
    private BluetoothDevice connectedDevice;
    private BluetoothGattCharacteristic targetCharacteristic;
    private UUID targetServiceUUID, targetCharacteristicUUID;
    private ScanCallback scanCallback;

    private static final UUID CLIENT_CONFIG_UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private String lastCompleteNotification = "";
    private StringBuilder notificationBuffer = new StringBuilder();
    private final List<BluetoothDevice> scannedDevices = new ArrayList<>();

    public BLEManager(Activity activity) {
        this.activity = activity;
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        bluetoothLeScanner = bluetoothAdapter != null ? bluetoothAdapter.getBluetoothLeScanner() : null;
        Log.d("BLEManager", "BLEManager initialized.");
    }

    public void setServiceUUID(String uuid) {
        targetServiceUUID = UUID.fromString(uuid);
    }

    public void setCharacteristicUUID(String uuid) {
        targetCharacteristicUUID = UUID.fromString(uuid);
    }

    // Start BLE scanning (General)
    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
    public void startScan() {
        if (!hasPermissions()) {
            requestPermissions();
            Log.w("BLEManager", "Permissions not granted. Requesting...");
            return;
        }
        if (bluetoothLeScanner == null) {
            Log.e("BLEManager", "BluetoothLeScanner not available.");
            return;
        }
        scannedDevices.clear();
        scanCallback = new ScanCallback() {
            @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
            @Override
            public void onScanResult(int callbackType, ScanResult result) {
                BluetoothDevice device = result.getDevice();
                if (device != null) {
                    Log.d("BLEManager", "Scanned device: " + device.getName() + " [" + device.getAddress() + "]");
                }
            }

            @Override
            public void onScanFailed(int errorCode) {
                Log.e("BLEManager", "Scan failed with error: " + errorCode);
            }
        };

        bluetoothLeScanner.startScan(scanCallback);
        Log.d("BLEManager", "BLE Scan started.");
    }

    // Stop BLE scanning
    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
    // Stop BLE scan with exception handling
    public void stopScan() {
        try {
            if (bluetoothLeScanner != null && scanCallback != null) {
                bluetoothLeScanner.stopScan(scanCallback);
                Log.d("BLEManager", "BLE scan stopped");
            }
        } catch (SecurityException e) {
            Log.e("BLEManager", "Stop scan failed due to security exception", e);
        }
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
    public void startScanAndConnect(final String deviceName) {
        if (!hasPermissions()) {
            requestPermissions();
            return;
        }

        bluetoothLeScanner.startScan(new ScanCallback() {
            @RequiresPermission(allOf = {Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN})
            @Override
            public void onScanResult(int callbackType, ScanResult result) {
                BluetoothDevice device = result.getDevice();
                if (device.getName() != null && device.getName().equals(deviceName)) {
                    bluetoothLeScanner.stopScan(this);
                    connectToDevice(device);
                }
            }

            @Override
            public void onScanFailed(int errorCode) {
                Log.e("BLEManager", "Scan failed: " + errorCode);
            }
        });
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    private void connectToDevice(BluetoothDevice device) {
        connectedDevice = device;
        bluetoothGatt = device.connectGatt(activity, false, new BluetoothGattCallback() {
            @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
            @Override
            public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    Log.d("BLEManager", "Connected to " + device.getName());
                    gatt.requestMtu(512);
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    Log.d("BLEManager", "Disconnected from " + device.getName());
                    connectedDevice = null;
                    bluetoothGatt = null;
                }
            }

            @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
            @Override
            public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    gatt.discoverServices();
                }
            }

            @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
            @Override
            public void onServicesDiscovered(BluetoothGatt gatt, int status) {
                BluetoothGattService service = gatt.getService(targetServiceUUID);
                if (service != null) {
                    targetCharacteristic = service.getCharacteristic(targetCharacteristicUUID);
                    if (targetCharacteristic != null) {
                        enableNotifications(gatt, targetCharacteristic);
                    }
                }
            }

            @Override
            public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
                byte[] value = characteristic.getValue();
                String hexData = bytesToHex(value);
                notificationBuffer.append(hexData).append(" ");
                lastCompleteNotification = notificationBuffer.toString().trim();
                notificationBuffer.setLength(0);
            }
        });
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    private void enableNotifications(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
        gatt.setCharacteristicNotification(characteristic, true);
        BluetoothGattDescriptor descriptor = characteristic.getDescriptor(CLIENT_CONFIG_UUID);
        if (descriptor != null) {
            descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
            gatt.writeDescriptor(descriptor);
        }
    }

    private String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) sb.append(String.format("%02X ", b));
        return sb.toString().trim();
    }

    public boolean isConnected() {
        return bluetoothGatt != null && connectedDevice != null;
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    public String getConnectedDeviceName() {
        return connectedDevice != null ? connectedDevice.getName() : "";
    }

    public String getLastNotificationData() {
        return lastCompleteNotification;
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    public void disconnectFromDevice() {
        if (bluetoothGatt != null) {
            bluetoothGatt.disconnect();
            bluetoothGatt.close();
            bluetoothGatt = null;
        }
        connectedDevice = null;
    }

    public boolean hasPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            boolean scan = ContextCompat.checkSelfPermission(activity, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED;
            boolean connect = ContextCompat.checkSelfPermission(activity, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
            boolean location = ContextCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;

            Log.d("BLEManager", "Permissions - SCAN: " + scan + ", CONNECT: " + connect + ", LOCATION: " + location);
            return scan && connect && location;
        } else {
            boolean location = ContextCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
            Log.d("BLEManager", "Permission LOCATION: " + location);
            return location;
        }
    }

    // Request missing permissions
    public void requestPermissions() {
        if (!hasPermissions()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                ActivityCompat.requestPermissions(activity,
                        new String[]{
                                Manifest.permission.BLUETOOTH_SCAN,
                                Manifest.permission.BLUETOOTH_CONNECT,
                                Manifest.permission.ACCESS_FINE_LOCATION
                        },
                        PERMISSION_REQUEST_CODE);
            } else {
                ActivityCompat.requestPermissions(activity,
                        new String[]{
                                Manifest.permission.ACCESS_FINE_LOCATION
                        },
                        PERMISSION_REQUEST_CODE);
            }
        }
    }
    // Handle permission request result (call this from your Activity's onRequestPermissionsResult)
    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            if (grantResults.length > 0) {
                for (int res : grantResults) {
                    if (res != PackageManager.PERMISSION_GRANTED) {
                        allGranted = false;
                        break;
                    }
                }
            } else {
                allGranted = false;
            }

            if (allGranted) {
                Log.d("BLEManager", "Permissions granted, starting BLE scan.");
                startScan();
            } else {
                Log.e("BLEManager", "Permissions denied by user.");
            }
        }
    }
    // Stop BLE scan with exception handling

}